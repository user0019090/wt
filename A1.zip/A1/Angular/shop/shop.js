// AngularJS Application
angular.module('shoppingApp', [])
    .service('CartService', function () {
        let cart = [];

        // Add item to cart
        this.addToCart = function (product) {
            cart.push(product);
        };

        // Remove item from cart
        this.removeFromCart = function (product) {
            const index = cart.indexOf(product);
            if (index > -1) {
                cart.splice(index, 1);
            }
        };

        // Get cart items
        this.getCart = function () {
            return cart;
        };

        // Calculate total
        this.getTotal = function () {
            return cart.reduce((sum, item) => sum + item.price, 0);
        };
    })
    .controller('ShoppingController', function ($scope, CartService) {
        // Product list
        $scope.products = [
            { name: 'Laptop', price: 800 },
            { name: 'Smartphone', price: 500 },
            { name: 'Headphones', price: 100 },
            { name: 'Keyboard', price: 50 }
        ];

        // Cart operations
        $scope.cart = CartService.getCart();

        $scope.addToCart = function (product) {
            CartService.addToCart(product);
        };

        $scope.removeFromCart = function (product) {
            CartService.removeFromCart(product);
        };

        $scope.getTotal = function () {
            return CartService.getTotal();
        };
    });
