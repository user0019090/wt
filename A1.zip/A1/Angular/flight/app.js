// Define AngularJS module and factory
var app = angular.module('travelApp', []);

// Create a factory to store travel packages
app.factory('PackageFactory', function() {
    var packages = [
        {
            name: 'Paris Getaway',
            flightDetails: 'Flight: NY to Paris - 10:00 AM',
            hotelName: 'Hotel Le Meurice',
            price: 1500,
            availableDates: ['2024-10-20', '2024-11-10', '2024-12-05']
        },
        {
            name: 'Tokyo Adventure',
            flightDetails: 'Flight: LA to Tokyo - 1:00 PM',
            hotelName: 'The Ritz-Carlton Tokyo',
            price: 1800,
            availableDates: ['2024-10-21', '2024-11-12', '2024-12-18']
        },
        {
            name: 'Rome Historical Tour',
            flightDetails: 'Flight: NY to Rome - 2:00 PM',
            hotelName: 'Hotel Hassler Roma',
            price: 1700,
            availableDates: ['2024-10-25', '2024-11-15', '2024-12-25']
        }
    ];

    return {
        getPackages: function() {
            return packages;
        }
    };
});

// Controller to manage travel packages and availability check
app.controller('PackageController', function($scope, PackageFactory, $filter) {
    $scope.packages = PackageFactory.getPackages();
    $scope.filteredPackages = $scope.packages; // Initially show all packages

    $scope.selectedDate = '';

    // Function to check availability based on selected date
    $scope.checkAvailability = function() {
        if ($scope.selectedDate) {
            var formattedDate = $filter('date')($scope.selectedDate, 'yyyy-MM-dd');
            $scope.filteredPackages = $scope.packages.filter(function(package) {
                return package.availableDates.includes(formattedDate);
            });
        } else {
            alert("Please select a date.");
            $scope.filteredPackages = $scope.packages; // Show all packages if no date is selected
        }
    };
});
