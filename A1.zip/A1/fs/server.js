const fs = require('fs');

// File path to be read
const filePath = 'example.txt';

// Reading the file asynchronously
fs.readFile(filePath, 'utf8', (err, data) => {
    if (err) {
        console.error('Error reading the file:', err.message);
        return;
    }
    console.log('File Content:\n', data);
});
