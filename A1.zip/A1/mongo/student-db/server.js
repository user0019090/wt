const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public')); // Serve static files

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/college', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

// Student schema and model
const studentSchema = new mongoose.Schema({
    usn: String,
    name: String,
    collegeName: String,
    branch: String,
    yearOfJoining: Number,
    email: String,
});

const Student = mongoose.model('Student', studentSchema);

// API to insert a student
app.post('/api/students', async (req, res) => {
    const newStudent = new Student(req.body);
    await newStudent.save();
    res.status(201).send(newStudent);
});

// API to get all students
app.get('/api/students', async (req, res) => {
    const students = await Student.find();
    res.status(200).send(students);
});

// API to update a student
app.put('/api/students/:id', async (req, res) => {
    const { id } = req.params;
    const updatedStudent = await Student.findByIdAndUpdate(id, req.body, { new: true });
    res.status(200).send(updatedStudent);
});

// API to delete a student
app.delete('/api/students/:id', async (req, res) => {
    const { id } = req.params;
    await Student.findByIdAndDelete(id);
    res.status(200).send({ message: 'Student deleted successfully' });
});

// Serve the HTML file when accessing the root URL
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/index.html'); // Update this path if necessary
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
