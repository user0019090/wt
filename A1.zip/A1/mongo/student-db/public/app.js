const app = angular.module('studentApp', []);

// StudentService to handle API calls
app.service('StudentService', ['$http', function($http) {
    this.getStudents = function() {
        return $http.get('http://localhost:5000/api/students');
    };

    this.addStudent = function(student) {
        return $http.post('http://localhost:5000/api/students', student);
    };

    this.updateStudent = function(student) {
        return $http.put(`http://localhost:5000/api/students/${student._id}`, student);
    };

    this.deleteStudent = function(studentId) {
        return $http.delete(`http://localhost:5000/api/students/${studentId}`);
    };
}]);

// Controller with dependency injection
app.controller('StudentController', ['$scope', 'StudentService', function($scope, StudentService) {
    $scope.students = [];
    $scope.newStudent = {};
    $scope.selectedStudent = null;

    // Retrieve students
    $scope.getStudents = function() {
        StudentService.getStudents().then(response => {
            $scope.students = response.data;
        });
    };

    // Add a new student
    $scope.addStudent = function() {
        StudentService.addStudent($scope.newStudent).then(response => {
            $scope.students.push(response.data);
            $scope.newStudent = {}; // Reset form
        });
    };

    // Edit student (populate form for editing)
    $scope.editStudent = function(student) {
        $scope.selectedStudent = angular.copy(student);
    };

    // Update student
    $scope.updateStudent = function() {
        StudentService.updateStudent($scope.selectedStudent).then(() => {
            $scope.getStudents(); // Refresh student list
            $scope.selectedStudent = null; // Clear form after updating
        });
    };

    // Delete student
    $scope.deleteStudent = function(studentId) {
        StudentService.deleteStudent(studentId).then(() => {
            $scope.getStudents(); // Refresh student list
        });
    };

    // Initial call to fetch students
    $scope.getStudents();
}]);

// Custom directive for student card
app.directive('studentCard', function() {
    return {
        restrict: 'E',
        scope: {
            student: '=',
            onEdit: '&',
            onDelete: '&'
        },
        template: `
            <div>
                <span>{{ student.usn }} - {{ student.name }} - {{ student.collegeName }} - {{ student.branch }} - {{ student.yearOfJoining }} - {{ student.email }}</span>
                <button ng-click="onEdit({student: student})">Edit</button>
                <button ng-click="onDelete({id: student._id})">Delete</button>
            </div>
        `
    };
});
