// Initialize Angular app
var app = angular.module("shoppingApp", []);

// Factory to manage API calls
app.factory("ProductService", [
  "$http",
  function ($http) {
    var baseUrl = "http://localhost:3000/api/products";
    return {
      getAllProducts: function () {
        return $http.get(baseUrl);
      },
      addProduct: function (product) {
        return $http.post(baseUrl, product);
      },
      updateProduct: function (product) {
        return $http.put(baseUrl + "/" + product._id, product);
      },
      deleteProduct: function (id) {
        return $http.delete(baseUrl + "/" + id);
      },
    };
  },
]);

// Main controller for the shopping app
app.controller("ShoppingController", [
  "$scope",
  "ProductService",
  function ($scope, ProductService) {
    $scope.products = [];
    $scope.newProduct = {};
    $scope.editing = false;

    // Load all products
    function loadProducts() {
      ProductService.getAllProducts().then(function (response) {
        $scope.products = response.data;
      });
    }

    loadProducts();

    // Add a new product
    $scope.addProduct = function () {
      // Check if product name and price are entered
      if (!$scope.newProduct.name || !$scope.newProduct.price) {
        alert("Product name and price are required!");
        return; // Don't proceed if the fields are empty
      }

      // Debugging step: Check what is being passed
      console.log("Adding new product:", $scope.newProduct);

      ProductService.addProduct($scope.newProduct).then(
        function (response) {
          console.log("Product added successfully:", response);
          loadProducts(); // Reload the product list
          $scope.newProduct = {}; // Clear input fields
        },
        function (error) {
          console.log("Error adding product:", error);
          alert("There was an error adding the product.");
        }
      );
    };

    // Delete a product
    $scope.deleteProduct = function (id) {
      ProductService.deleteProduct(id).then(function () {
        loadProducts();
      });
    };

    // Edit a product
    $scope.editProduct = function (product) {
      $scope.editing = true;
      $scope.editingProduct = angular.copy(product);
    };

    // Update product
    $scope.updateProduct = function () {
      ProductService.updateProduct($scope.editingProduct).then(function () {
        $scope.editing = false;
        loadProducts();
      });
    };

    // Cancel edit
    $scope.cancelEdit = function () {
      $scope.editing = false;
      $scope.editingProduct = {};
    };
  },
]);

// Custom filter for product search
app.filter("productSearch", function () {
  return function (products, searchText) {
    if (!searchText) {
      return products; // If no search term, return all products
    }
    return products.filter(function (product) {
      return (
        product.name.toLowerCase().includes(searchText.toLowerCase()) ||
        (product.description &&
          product.description.toLowerCase().includes(searchText.toLowerCase()))
      );
    });
  };
});
