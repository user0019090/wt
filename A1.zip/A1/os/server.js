// Import the os module
const os = require('os');

// Get system architecture
console.log(`System Architecture: ${os.arch()}`);

// Get the operating system platform
console.log(`Platform: ${os.platform()}`);

// Get the number of CPUs
console.log(`CPU Info:`, os.cpus());

// Get free memory in bytes
console.log(`Free Memory: ${os.freemem()} bytes`);

// Get total memory in bytes
console.log(`Total Memory: ${os.totalmem()} bytes`);

// Get hostname of the system
console.log(`Hostname: ${os.hostname()}`);

// Get network interfaces
console.log(`Network Interfaces:`, os.networkInterfaces());

// Get operating system type
console.log(`OS Type: ${os.type()}`);

// Get the system uptime in seconds
console.log(`System Uptime: ${os.uptime()} seconds`);

// Get the user's home directory
console.log(`Home Directory: ${os.homedir()}`);

// Get temporary directory
console.log(`Temp Directory: ${os.tmpdir()}`);

// Get the current user information
console.log(`User Info:`, os.userInfo());
